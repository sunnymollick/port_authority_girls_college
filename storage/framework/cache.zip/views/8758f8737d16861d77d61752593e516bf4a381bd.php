<!-- Hero section -->
<?php if($birthday->count()>0): ?>
    <section class="fact-section spad set-bg" data-setbg="<?php echo e(asset('assets/images/birthday.jpg')); ?>">
        <div class="container">
            <div id="snow"></div>
            <div class="row">
                <div class="section-title text-center">
                    <h2>Happy Birthday To ...</h2>
                    <p>Many many happy returns of the day</p>
                </div>
                <?php $__currentLoopData = $birthday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 col-sm-12">
                        <div class="member">
                            <div class="member-pic set-bg" data-setbg="<?php echo e(asset($row->file_path)); ?>"
                                 style="max-width: 150px;max-height: 150px;opacity: .80"></div>
                            <h6><?php echo e($row->std_name); ?></h6>
                            <h6>[<?php echo e($row->std_code); ?>]</h6>
                            <p>Class : <?php echo e($row->class_name); ?>, Section : <?php echo e($row->section); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Hero section end -->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/birthday_snow.css')); ?>">
    <script src="<?php echo e(asset('assets/js/birthday_snow.js')); ?>"></script>
<?php endif; ?>
