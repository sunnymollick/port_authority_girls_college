<!-- Hero section -->
<?php if($sliders): ?>
    <section class="hero-section">
        <div class="hero-slider owl-carousel">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="hs-item set-bg" data-setbg="<?php echo e(asset($slider->file_path)); ?>">
                    <div class="hs-text">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="hs-subtitle"><?php echo e($slider->sub_title); ?></div>
                                    <h2 class="hs-title"><?php echo e($slider->title); ?></h2>
                                    <p class="hs-des"><?php echo e($slider->description); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- Hero section end -->
<?php endif; ?>