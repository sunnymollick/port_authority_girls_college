<!-- widget -->
<?php
    $notices = \App\Models\News::where('category', 'Notice Board')->orderby('created_at', 'desc')->take(6)->get();
?>
<div class="widget">
    <?php if($notices): ?>
        <h4>Notice Board</h4>
        <hr/>
        <div class="recent-post-widget">
            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rp-item">
                    <img class="rp-thumb set-bg" src="<?php echo e(asset('assets/images/blog/notice.png')); ?>"/>
                    <div class="rp-content">
                        <a href="<?php echo e(URL :: to('/viewNews/'.$notice->id)); ?>">
                            <h6><strong style="font-size: 16px"><?php echo e($notice->title); ?></strong></h6></a>
                        <p><i class="fa fa-clock-o"></i> <?php echo e(date('dS F, Y', strtotime($notice->created_at))); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <br/>
        <div>
            <a href="<?php echo e(URL :: to('/academicNotices')); ?>" class="btn btn-primary btn-block">View all Notices</a>
        </div>
    <?php endif; ?>
</div>