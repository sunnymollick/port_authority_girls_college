<!-- latest_news section -->
<?php if($latest_news): ?>
    <section class="blog-section spad">
        <div class="row">
            <div class="col-md-12 col-sm-12 section-title text-center">
                <h3>CBMC LATEST NEWS</h3>
                <p>All News from CBMC</p>
            </div>
            <div class="col-md-12 col-sm-12">
                <?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="blog-item">
                            <div class="blog-thumb set-bg" data-setbg="<?php echo e(asset($news->file_path)); ?>"></div>
                            <div class="blog-content">
                                <a href="<?php echo e(URL :: to('/viewNews/'.$news->id)); ?>">
                                    <h4><?php echo e($news->title); ?></h4></a>
                                <div class="blog-meta">
                                    <span><i class="fa fa-calendar-o"></i> <?php echo e($news->created_at); ?></span>
                                    <span><i
                                            class="fa fa-user"></i> <?php echo e($news->author? $news->author->name : ''); ?></span>
                                </div>
                                <p><?php echo e(str_limit($news->description, 100)); ?> <a
                                        href="<?php echo e(URL :: to('/viewNews/'.$news->id)); ?>" class="text-green">Read
                                        More</a>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>
<!-- latest_news section -->