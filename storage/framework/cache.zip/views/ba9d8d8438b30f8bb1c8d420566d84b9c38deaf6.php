<link href="<?php echo e(asset('/assets/datatables/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"
      type="text/css"/>
<link href="<?php echo e(asset('/assets/datatables/css/responsive.dataTables.min.css')); ?>" rel="stylesheet"
      type="text/css"/>


<script src="<?php echo e(asset('/assets/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/datatables/js/dataTables.select.min.js')); ?>"></script>


